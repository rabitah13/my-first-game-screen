import pygame

pygame.init()

screen = pygame.display.set_mode((800, 600))

white = (300, 300, 300)
blue = (0, 0, 300)

running = True
while running:
  
   screen.fill(white)
  
  pygame.draw.rect(screen, blue, (400, 350, 200, 200))
  
  
for event in pygame.event.get():
  if event.type == pygame.QUIT:
      running = False
      
  pygame.display.update()
  
pygame.quit()




  
      
  
  